"""
datamorph/converter.py
─────────────────────────────────────────────────────────────────────────────
The Lazy Dragon's DataMorph — Core Converter Library
Author : The Lazy Dragon (怠竜 Tearyū)
GitHub : https://github.com/The-Lazy-Dragon
─────────────────────────────────────────────────────────────────────────────
Public API
    detect_format(path_or_content)   → "csv" | "json" | "xml"
    convert(data, source, target)    → str
    convert_file(in_path, out_path)  → None
─────────────────────────────────────────────────────────────────────────────
"""

from __future__ import annotations

import csv
import io
import json
import os
import re
import xml.etree.ElementTree as ET
from typing import Any
from xml.dom import minidom


# ─────────────────────────────────────────────────────────────────────────────
# FORMAT DETECTION
# ─────────────────────────────────────────────────────────────────────────────

_EXTENSION_MAP: dict[str, str] = {
    ".csv": "csv",
    ".json": "json",
    ".xml": "xml",
}


def detect_format(path_or_content: str) -> str:
    """
    Detect the data format from a file path (extension) or raw content.

    Tries file extension first, then falls back to content sniffing.

    Parameters
    ----------
    path_or_content : str
        A filesystem path *or* the raw text content.

    Returns
    -------
    str
        ``"csv"``, ``"json"``, or ``"xml"``

    Raises
    ------
    DataMorphError
        If the format cannot be determined.
    """
    # --- Extension hint -------------------------------------------------------
    ext = os.path.splitext(path_or_content)[-1].lower()
    if ext in _EXTENSION_MAP:
        return _EXTENSION_MAP[ext]

    # --- Content sniffing -----------------------------------------------------
    sample = path_or_content.strip()

    if sample.startswith("<"):
        return "xml"

    if sample.startswith(("{", "[")):
        try:
            json.loads(sample)
            return "json"
        except json.JSONDecodeError:
            pass

    # Heuristic: multiple lines, consistent comma count → CSV
    lines = [ln for ln in sample.splitlines() if ln.strip()]
    if len(lines) >= 2:
        comma_counts = [ln.count(",") for ln in lines[:5]]
        if all(c == comma_counts[0] and c >= 1 for c in comma_counts):
            return "csv"

    raise DataMorphError(
        "Cannot detect format — not a recognisable CSV, JSON, or XML structure. "
        "Pass --from to specify the source format explicitly."
    )


# ─────────────────────────────────────────────────────────────────────────────
# EXCEPTIONS
# ─────────────────────────────────────────────────────────────────────────────

class DataMorphError(ValueError):
    """Raised for all conversion / validation errors."""


# ─────────────────────────────────────────────────────────────────────────────
# PARSERS  (raw text → Python objects)
# ─────────────────────────────────────────────────────────────────────────────

def _parse_csv(text: str) -> list[dict[str, Any]]:
    """
    Parse CSV text into a list of row-dicts.

    Handles:
    * BOM prefix (UTF-8-with-BOM files from Excel)
    * Quoted fields containing commas or newlines
    * Empty rows (skipped)
    * Missing values (kept as empty string)
    """
    text = text.lstrip("\ufeff")  # strip BOM
    reader = csv.DictReader(io.StringIO(text))
    try:
        rows = [dict(row) for row in reader if any(v for v in row.values())]
    except csv.Error as exc:
        raise DataMorphError(f"Malformed CSV: {exc}") from exc
    if not rows:
        raise DataMorphError("CSV is empty or has no data rows.")
    return rows


def _parse_json(text: str) -> Any:
    """
    Parse JSON text, returning the root object (list or dict).

    Raises DataMorphError with the position of the first syntax error.
    """
    try:
        return json.loads(text)
    except json.JSONDecodeError as exc:
        raise DataMorphError(
            f"Malformed JSON at line {exc.lineno}, col {exc.colno}: {exc.msg}"
        ) from exc


def _parse_xml(text: str) -> ET.Element:
    """
    Parse XML text into an ElementTree Element.

    Raises DataMorphError with a human-readable parse error.
    """
    try:
        return ET.fromstring(text.strip())
    except ET.ParseError as exc:
        raise DataMorphError(f"Malformed XML: {exc}") from exc


# ─────────────────────────────────────────────────────────────────────────────
# INTERNAL HELPERS
# ─────────────────────────────────────────────────────────────────────────────

def _safe_tag(name: str) -> str:
    """
    Turn an arbitrary string into a legal XML tag name.

    Rules applied:
    * Leading digits / punctuation → prefixed with ``_``
    * Spaces and ``/`` → replaced with ``_``
    * Characters outside [a-zA-Z0-9._-] → stripped
    """
    name = re.sub(r"[\s/\\]", "_", name)
    name = re.sub(r"[^\w.\-]", "", name, flags=re.ASCII)
    if name and name[0].isdigit():
        name = f"_{name}"
    return name or "field"


def _flatten(obj: Any, prefix: str = "") -> dict[str, str]:
    """
    Recursively flatten a nested dict/list into ``dot.notation`` keys.

    Example
    -------
    ``{"a": {"b": 1}, "c": [2, 3]}``
    → ``{"a.b": "1", "c.0": "2", "c.1": "3"}``
    """
    items: dict[str, str] = {}
    if isinstance(obj, dict):
        for k, v in obj.items():
            full_key = f"{prefix}.{k}" if prefix else k
            items.update(_flatten(v, full_key))
    elif isinstance(obj, list):
        for i, v in enumerate(obj):
            full_key = f"{prefix}.{i}" if prefix else str(i)
            items.update(_flatten(v, full_key))
    else:
        items[prefix] = "" if obj is None else str(obj)
    return items


def _build_xml_element(parent: ET.Element, key: str, value: Any) -> None:
    """
    Recursively attach *value* under a child element named *key*.

    * dict  → child element with recursive children
    * list  → repeated ``<item>`` children
    * scalar → text content
    """
    tag = _safe_tag(key)
    child = ET.SubElement(parent, tag)
    if isinstance(value, dict):
        for k, v in value.items():
            _build_xml_element(child, k, v)
    elif isinstance(value, list):
        for item in value:
            _build_xml_element(child, "item", item)
    else:
        child.text = "" if value is None else str(value)


def _element_to_dict(element: ET.Element) -> Any:
    """
    Convert an XML Element tree to a Python dict.

    Attributes are stored under ``@attributes``.
    Text content is stored under ``#text`` when the element also has children.
    A plain text-only element returns its string value directly.
    """
    result: dict[str, Any] = {}

    # Attributes
    if element.attrib:
        result["@attributes"] = dict(element.attrib)

    children = list(element)

    if not children:
        text = (element.text or "").strip()
        if result:  # has attributes
            if text:
                result["#text"] = text
            return result
        return text  # leaf with no attributes → plain string

    # Group repeated tags
    child_dict: dict[str, list[Any]] = {}
    for child in children:
        child_dict.setdefault(child.tag, []).append(_element_to_dict(child))

    for tag, items in child_dict.items():
        result[tag] = items[0] if len(items) == 1 else items

    # Inline text (mixed content)
    text = (element.text or "").strip()
    if text:
        result["#text"] = text

    return result


def _pretty_xml(root: ET.Element) -> str:
    """Return a pretty-printed, UTF-8 declared XML string."""
    raw = ET.tostring(root, encoding="unicode")
    reparsed = minidom.parseString(raw)
    lines = reparsed.toprettyxml(indent="  ").splitlines()
    # toprettyxml adds its own declaration; keep it
    return "\n".join(lines)


# ─────────────────────────────────────────────────────────────────────────────
# CONVERTERS  (Python objects → output format text)
# ─────────────────────────────────────────────────────────────────────────────

def _rows_to_json(rows: list[dict]) -> str:
    return json.dumps(rows, ensure_ascii=False, indent=2)


def _rows_to_xml(rows: list[dict]) -> str:
    root = ET.Element("records")
    for row in rows:
        record = ET.SubElement(root, "record")
        for key, value in row.items():
            _build_xml_element(record, key, value)
    return _pretty_xml(root)


def _json_to_csv(data: Any) -> str:
    # Normalise to a list of flat dicts
    if isinstance(data, dict):
        data = [data]

    if not isinstance(data, list):
        raise DataMorphError(
            "JSON root must be an array or object to convert to CSV. "
            "Got: " + type(data).__name__
        )

    flat_rows = [_flatten(row) for row in data]
    # Collect all keys in encounter order
    all_keys: list[str] = []
    seen: set[str] = set()
    for row in flat_rows:
        for k in row:
            if k not in seen:
                all_keys.append(k)
                seen.add(k)

    out = io.StringIO()
    writer = csv.DictWriter(out, fieldnames=all_keys, extrasaction="ignore", lineterminator="\n")
    writer.writeheader()
    for row in flat_rows:
        writer.writerow({k: row.get(k, "") for k in all_keys})
    return out.getvalue()


def _json_to_xml(data: Any) -> str:
    root = ET.Element("root")
    if isinstance(data, list):
        root.tag = "records"
        for item in data:
            _build_xml_element(root, "record", item)
    elif isinstance(data, dict):
        for k, v in data.items():
            _build_xml_element(root, k, v)
    else:
        root.text = str(data)
    return _pretty_xml(root)


def _xml_to_json(element: ET.Element) -> str:
    d = {element.tag: _element_to_dict(element)}
    return json.dumps(d, ensure_ascii=False, indent=2)


def _xml_to_csv(element: ET.Element) -> str:
    """
    Heuristic: if the XML has a uniform list of children we treat each child
    as a row and flatten its sub-elements into columns.
    Falls back to flattening the entire element dict otherwise.
    """
    children = list(element)
    if not children:
        raise DataMorphError("XML root element has no children to convert to CSV rows.")

    # Check uniformity
    first_tag = children[0].tag
    if all(c.tag == first_tag for c in children):
        rows = [_flatten(_element_to_dict(c)) for c in children]
    else:
        # Non-uniform → single flattened row per top-level child
        rows = [_flatten({c.tag: _element_to_dict(c)}) for c in children]

    all_keys: list[str] = []
    seen: set[str] = set()
    for row in rows:
        for k in row:
            if k not in seen:
                all_keys.append(k)
                seen.add(k)

    out = io.StringIO()
    writer = csv.DictWriter(out, fieldnames=all_keys, lineterminator="\n")
    writer.writeheader()
    for row in rows:
        writer.writerow({k: row.get(k, "") for k in all_keys})
    return out.getvalue()


# ─────────────────────────────────────────────────────────────────────────────
# PUBLIC API
# ─────────────────────────────────────────────────────────────────────────────

def convert(data: str, source_fmt: str, target_fmt: str) -> str:
    """
    Convert *data* from *source_fmt* to *target_fmt*.

    Parameters
    ----------
    data : str
        Raw text content of the source file.
    source_fmt : str
        ``"csv"``, ``"json"``, or ``"xml"``
    target_fmt : str
        ``"csv"``, ``"json"``, or ``"xml"``

    Returns
    -------
    str
        The converted text.

    Raises
    ------
    DataMorphError
        On parse failures, unsupported paths, or empty input.
    """
    source_fmt = source_fmt.lower().strip()
    target_fmt = target_fmt.lower().strip()

    supported = {"csv", "json", "xml"}
    if source_fmt not in supported:
        raise DataMorphError(f"Unsupported source format: '{source_fmt}'. Choose csv/json/xml.")
    if target_fmt not in supported:
        raise DataMorphError(f"Unsupported target format: '{target_fmt}'. Choose csv/json/xml.")

    if not data.strip():
        raise DataMorphError("Input is empty.")

    if source_fmt == target_fmt:
        return data  # no-op

    # ── CSV source ──────────────────────────────────────────────────────────
    if source_fmt == "csv":
        rows = _parse_csv(data)
        if target_fmt == "json":
            return _rows_to_json(rows)
        if target_fmt == "xml":
            return _rows_to_xml(rows)

    # ── JSON source ─────────────────────────────────────────────────────────
    if source_fmt == "json":
        parsed = _parse_json(data)
        if target_fmt == "csv":
            return _json_to_csv(parsed)
        if target_fmt == "xml":
            return _json_to_xml(parsed)

    # ── XML source ──────────────────────────────────────────────────────────
    if source_fmt == "xml":
        element = _parse_xml(data)
        if target_fmt == "json":
            return _xml_to_json(element)
        if target_fmt == "csv":
            return _xml_to_csv(element)

    raise DataMorphError(f"Conversion path {source_fmt} → {target_fmt} is not implemented.")


def convert_file(input_path: str, output_path: str,
                 source_fmt: str | None = None,
                 target_fmt: str | None = None) -> None:
    """
    Convert the file at *input_path* and write the result to *output_path*.

    Format detection
    ~~~~~~~~~~~~~~~~
    * *source_fmt* defaults to ``detect_format(input_path)``
    * *target_fmt* defaults to ``detect_format(output_path)``

    Parameters
    ----------
    input_path : str
        Path to the source file.
    output_path : str
        Path for the converted output file.
    source_fmt : str, optional
        Override source format detection.
    target_fmt : str, optional
        Override target format detection.

    Raises
    ------
    FileNotFoundError
        If *input_path* does not exist.
    DataMorphError
        On any conversion error.
    """
    if not os.path.isfile(input_path):
        raise FileNotFoundError(f"Input file not found: {input_path}")

    with open(input_path, "r", encoding="utf-8") as fh:
        data = fh.read()

    src = source_fmt or detect_format(input_path)
    tgt = target_fmt or detect_format(output_path)

    result = convert(data, src, tgt)

    os.makedirs(os.path.dirname(os.path.abspath(output_path)), exist_ok=True)
    with open(output_path, "w", encoding="utf-8") as fh:
        fh.write(result)
